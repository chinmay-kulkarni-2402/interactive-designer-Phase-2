function textTrackerPlugin(editor) {

}
